import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../user.service'
import { UserModel } from '../user.model'

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  @Input()
  private user: UserModel;

  constructor(private userService: UserService) { }

  ngOnInit() {
  }

  private removeUser(): void {
    this.userService.removeUser(this.user.id);
  }

}
