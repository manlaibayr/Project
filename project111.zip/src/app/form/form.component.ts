import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  public userText: string;
  public userEmail: string;
  public lastName: string;
  country: any;

  constructor(private userService: UserService) {
    
  }

  ngOnInit() {
  }

  private addUser(): void {
    this.userService.addUser(this.userText, this.userEmail, this.lastName);

  }
}
